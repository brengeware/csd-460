<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" import = "java.sql.ResultSet, java.time.LocalDate"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<jsp:useBean id = "database" class = "beans.DatabaseBean" />
	<%
		database.connectToDatabase();
		out.print("User ID: " + database.getUserID("example@example.com") + "<br>");
		try {
			out.print("Failed ID: " + database.getUserID("Not a real email") + "<br>");
		} catch (Exception e) {
			out.print("Exception caught<br>");
		}
		
		ResultSet firstRoom = database.getRoomByID(1);
		
		out.print("Room size: " + firstRoom.getString("name") + "<br>");
		out.print("Room price: " + firstRoom.getInt("price") + "<br>");
		
		try {
			ResultSet secondRoom = database.getRoomByID(100);
			out.print("Room size: " + secondRoom.getString("name") + "<br>");
			out.print("Room price: " + secondRoom.getInt("price") + "<br>");
		} catch (Exception e) {
			out.print(e.getMessage() + "<br>");
		}
		
		ResultSet rooms = database.getRoomIDs();
		while (rooms.next()) {
			ResultSet room = database.getRoomByID(rooms.getInt("size_id"));
			out.print("Room size: " + room.getString("name") + "<br>");
			out.print("Room price: " + room.getInt("price") + "<br><br>");
		}
		
		if (database.createReservation(1, 4, 2, LocalDate.of(2026, 11, 7), LocalDate.of(2026, 11, 9))) {
			out.print("Reservation created<br>");
		} else {
			out.print("Reservation failed<br>");
		}
		
		if (database.createReservation(10000, 4, 2, LocalDate.now(), LocalDate.of(2026, 10, 18))) {
			out.print("Reservation created<br>");
		} else {
			out.print("Reservation failed<br>");
		}
	%>

</body>
</html>