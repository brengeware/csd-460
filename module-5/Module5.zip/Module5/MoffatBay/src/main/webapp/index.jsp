
<%@ taglib prefix = "navbar" uri = "WEB-INF/tlds/NavigationBarTld.tld" %>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        
        <title>Moffat Bay Resort</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <header>
            <navbar:NavigationBar />
        </header>
    <div style="text-align: center;">
        <figure>
        <img src="lakeview.png" alt="Lake View" style="width: 75%;">
            <figcaption>Image from <a href="https://www.airbnb.com/rooms/1453087922354914768?source_impression_id=p3_1791599764_P3SMK693BEpM_Tfr&modal=PHOTO_TOUR_SCROLLABLE&modalItem=2283073223">Airbnb (Veazey Cove)</a></figcaption>
        </figure>
    </div>
    <div class="container">
        <h1>Moffat Bay's Premier Waterfront Resort</h1>
        <p>Relax and unwind at a lodge on Moffat Bay. With our cozy lodge cabins overlooking the serene waters of the bay, you'll find a calming resort designed to allow you to rejuvenate and recharge.</p>
    </div>
    <br>
    <hr>
    <br>
    <div class="section">
        <div class="left">
            <figure>
            <img src="roomview.png" alt="Cozy Cabin" style="width: 70%;">
                <figcaption>Image from <a href="https://www.artfulliving.com/montenegro-new-french-riviera/">ArtfulLiving</a></figcaption>
            </figure>
            <figure>
            <img src="mountview.png" alt="Mountain View" style="width: 70%;">
                <figcaption>Image from <a href="https://www.visitglacierbay.com/lodging-camping/glacier-bay-lodge/">VisitGlacierBay</a></figcaption>
            </figure>
        </div>
        <div class="right">
            <h1>At the Heart of It All</h1>
            <p>Nestled in the middle of the region, our resort is minutes away from restaurants, boardwalks, and attractions. Grab a bite to eat before taking a stroll down the sidewalk overlooking the beautiful calming waters, or grab a boat and ride the bay all the way through the mountain range and back. You're never out of things to do, and there's always more around the corner.</p>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <div class="container">
        <h3>What are you waiting for? The Bay is calling! Book your room now!</h3>
        <button class="button">Book a Reservation</button>
    </div>
    <br><br>
    <footer>
        <div class="footer-content">
            <div>
                <p><img src="logo.png" alt="Moffat Bay Logo" width="60px" style="vertical-align: middle;"><b>Moffat Bay Resort</b></p>
                <p>1234 Body of Water St</p>
                <p>Anytown, Anystate 12345</p>
                <p>(123) 456-7890</p>
            </div>
            <div style="text-align: right;">
                <p><b>Quick Links</b></p>
                <p><a class="foota" href="#">Book a Room</a></p>
                <p><a class="foota" href="#">Contact Us</a></p>
            </div>
        </div>
        <div class="footer-line"></div>
        <p>© 2028 Moffat Bay, LLC. All rights reserved.</p>
    </footer>
</body>
</html>